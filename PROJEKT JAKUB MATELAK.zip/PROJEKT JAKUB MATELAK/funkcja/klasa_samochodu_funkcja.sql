/* Funkcja wyświetla klase samochodu, po wpisaniu przez nas danego modelu samochodu */

CREATE DEFINER=`root`@`localhost` FUNCTION `klasa_samochodu`(model_samochodu VARCHAR(30)) RETURNS varchar(30) CHARSET utf8mb4
    DETERMINISTIC
BEGIN
DECLARE klasa_samochodu VARCHAR(30);
IF (model_samochodu='s7' OR model_samochodu='q8')  THEN
SET klasa_samochodu='luksusowa';
ELSEIF (model_samochodu='a3' OR model_samochodu='e90' OR model_samochodu='e61' OR model_samochodu='180') THEN
SET klasa_samochodu='premium';
ELSEIF (model_samochodu='panda' OR model_samochodu='punto' OR model_samochodu='fabia' OR model_samochodu='rapid') THEN
SET klasa_samochodu='miejska';
ELSEIF (model_samochodu='golf' OR model_samochodu='focus' OR model_samochodu='astra' ) THEN
SET klasa_samochodu='kompakt';
ELSEIF (model_samochodu='voyager' OR model_samochodu='transit' ) THEN
SET klasa_samochodu='van';
ELSEIF model_samochodu='croma'   THEN
SET klasa_samochodu='średnia';
ELSEIF (model_samochodu='x3' OR model_samochodu='wrangler' ) THEN
SET klasa_samochodu='suv';
ELSEIF (model_samochodu='911' OR model_samochodu='panamera' ) THEN
SET klasa_samochodu='sportowa';
ELSEIF model_samochodu='kangoo'   THEN
SET klasa_samochodu='kombivan';
ELSEIF model_samochodu='agila'   THEN
SET klasa_samochodu='microvan';

END IF;
RETURN klasa_samochodu;

END