CREATE TABLE wypozyczenie(
id_wypozyczenia INT,
id_klienta INT,
id_samochodu INT,
miejsce_odebrania VARCHAR(30),
miejsce_zostawienia VARCHAR(30),
data_od DATE,
data_do DATE
);