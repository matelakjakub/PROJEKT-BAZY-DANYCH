CREATE TABLE cennik (
    klasa_samochodu VARCHAR(30),
    cena_godzina VARCHAR(10),
    cena_doba VARCHAR(10),
    data_zmiany DATETIME,
    poprzednia_cena VARCHAR(30)
);