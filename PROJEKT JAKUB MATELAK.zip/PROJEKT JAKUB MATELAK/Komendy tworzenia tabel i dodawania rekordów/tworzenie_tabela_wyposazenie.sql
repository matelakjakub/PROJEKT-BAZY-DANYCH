CREATE TABLE wyposazenie(
id_samochodu INT,
klimatyzacja VARCHAR(10),
podgrzewane_fotele VARCHAR(10),
abs VARCHAR(10),
hak VARCHAR(10),
tempomat VARCHAR(10)
);

