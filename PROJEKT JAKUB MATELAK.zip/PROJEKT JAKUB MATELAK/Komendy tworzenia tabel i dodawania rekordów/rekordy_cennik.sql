USE wypozyczalnia;
INSERT INTO cennik(klasa_samochodu,cena_godzina,cena_doba) VALUES
('luksusowa','300zł','900zł'),
('premium','240zł','600zł'),
('miejska','120zł','350zł'),
('kompakt','140zł','330zł'),
('van','400zł','500zł'),
('mini','80zł','250zł'),
('średnia','200zł','500zł'),
('suv','399zł','699zł'),
('sportowa','500zł','1099zł'),
('kombivan','299zł','449zł'),
('microvan','999zł','1299zł');
