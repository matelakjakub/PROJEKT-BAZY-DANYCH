USE wypozyczalnia;
INSERT INTO klienci(id_klienta,imie,nazwisko,pesel,adres,nr_telefonu,miasto_zamieszkania,data_urodzenia) VALUES
('1','Krystian','Ułanowicz','01824232826','Bulwarowa 13','827312831','Warszawa','2001-01-23'),
('2','Patryk','Brogowski','97289412592','Modrzewiowa 123','827472919','Warszawa','1997-05-24'),
('3','Karol','Naruszewicz','87273729922','Rynek 1','522732123','Warszawa','1987-07-15'),
('4','Jakub','Kamiński','72375928018','Hiacyntowa 14','943677842','Kraków','1972-11-14'),
('5','Łukasz','Grabek','98827489112','Lubasiowa 34','776422387','Kraków','1998-04-13'),
('6','Tomasz','Zakrzewski','65590087299','Pistacjowa 13','689882654','Gdańsk','1965-02-02'),
('7','Hubert','Mackiewicz','99821235320','Józefa Burby 4','666782901','Gdańsk','1999-12-28'),
('8','Maja','Baranowska','01294721951','Brzostowskiego 48','677975472','Kraków','2001-05-07'),
('9','Krystyna','Wilczyńska','09727568211','Chorobowa 100','515478726','Białystok','1978-11-11'),
('10','Michał ','Taraszkiewicz','76291002142','Grzybiarska 24','788912092','Białystok','1976-06-25'),
('11','Bartosz','Ostrokołowicz','99824756901','Zalew 42','505087652','Choroszcz','1999-07-04'),
('12','Jakub','Bezdziecki','91892459028','Kusa 98','693432233','Toruń','1991-06-14'),
('13','Kinga','Manalis','76659088890','Rabinowa 90','755900821','Toruń','1976-01-20'),
('14','Julia','Lik','96908722901','Łazińska 14','567852778','Olsztyn','1996-04-29'),
('15','Kacper','Matelak','99827128390','Kościuszki 98','672889242','Olsztyn','1999-09-01');



