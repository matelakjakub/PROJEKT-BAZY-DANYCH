CREATE TABLE klienci (
    id_klienta INT,
    imie VARCHAR(20),
    nazwisko VARCHAR(40),
    pesel VARCHAR(15),
    adres VARCHAR(50),
    nr_telefonu INT,
    miasto_zamieszkania VARCHAR(15),
    data_urodzenia DATE,
    dodanie DATETIME
);