CREATE TABLE samochody(
id_samochodu INT,
marka_samochodu VARCHAR(30),
model_samochodu VARCHAR(30), 
rodzaj_silnika VARCHAR(10),
moc_silnika INT,
klasa_samochodu VARCHAR(30),
rocznik_samochodu INT,
kolor_samochodu VARCHAR(20),
pojemnosc_silnika VARCHAR(3),
nr_rejestracyjny TEXT


);