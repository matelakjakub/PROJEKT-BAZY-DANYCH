CREATE TABLE przeglad(
id_samochodu INT,
data_od DATE,
data_do DATE
);