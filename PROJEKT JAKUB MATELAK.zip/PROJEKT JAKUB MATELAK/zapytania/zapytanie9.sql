/*Zapytanie wyświetla srednie spalanie poszczególnej klasy samochodu w wypozyczalni, zaokraglone do 3 miejsce po przecinku*/

CREATE VIEW `zapytanie9` AS
SELECT klasa_samochodu,
 (SELECT ROUND(AVG(pojemnosc_silnika),3)) AS 'srednie spalanie'  FROM samochody GROUP BY klasa_samochodu;
