/*Zapytanie wyświetla poszczegolne informacje o kliencie z danym id*/

CREATE VIEW `zapytanie7` AS
SELECT wypozyczenie.id_wypozyczenia,
 wypozyczenie.id_klienta,
 klienci.imie,
 klienci.nazwisko
 FROM klienci RIGHT OUTER JOIN wypozyczenie
 ON wypozyczenie.id_klienta=klienci.id_klienta
 WHERE wypozyczenie.id_wypozyczenia=9;
