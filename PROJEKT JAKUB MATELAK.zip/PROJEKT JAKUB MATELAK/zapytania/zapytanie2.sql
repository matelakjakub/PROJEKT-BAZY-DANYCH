/*Zapytanie wyświetla poszczególne informacje o samochodach z tabeli samochody oraz elementy wyposazenia samochodów malejąco na podstawie id_samochodu*/
CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `zapytanie2` AS
    SELECT 
        `samochody`.`id_samochodu` AS `id_samochodu`,
        `samochody`.`marka_samochodu` AS `marka_samochodu`,
        `samochody`.`kolor_samochodu` AS `kolor_samochodu`,
        `wyposazenie`.`hak` AS `hak`,
        `wyposazenie`.`abs` AS `abs`,
        `wyposazenie`.`klimatyzacja` AS `klimatyzacja`
    FROM
        (`wyposazenie`
        LEFT JOIN `samochody` ON ((`samochody`.`id_samochodu` = `wyposazenie`.`id_samochodu`)))
    ORDER BY `samochody`.`id_samochodu` DESC