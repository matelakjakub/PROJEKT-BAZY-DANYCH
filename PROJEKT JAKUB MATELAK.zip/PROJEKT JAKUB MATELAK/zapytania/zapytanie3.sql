/*Zapytanie wyświetla  id samochodu, wypozyczonego przez osobe o danym id*/
CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `zapytanie3` AS
    SELECT 
        `klienci`.`id_klienta` AS `Id klienta`,
        `wypozyczenie`.`id_samochodu` AS `Id wypozyczonego samochodu`
    FROM
        (`wypozyczenie`
        LEFT JOIN `klienci` ON ((`klienci`.`id_klienta` = `wypozyczenie`.`id_klienta`)))