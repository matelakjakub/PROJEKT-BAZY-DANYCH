/*Zapytanie wyswietla ilosc marek samochodow,ilosc modeli samochodow oraz najstarszy i najmłodszy samochód wypożyczalni*/
CREATE VIEW `zapytanie6` AS
SELECT COUNT(model_samochodu) AS "Ilosc modeli samochodow", 
COUNT(DISTINCT marka_samochodu) AS "Ilosc marek samochodow", 
MAX(rocznik_samochodu) AS "Najmlodszy samochod",
MIN(rocznik_samochodu) AS "Najstarszy samochod"
FROM samochody;
