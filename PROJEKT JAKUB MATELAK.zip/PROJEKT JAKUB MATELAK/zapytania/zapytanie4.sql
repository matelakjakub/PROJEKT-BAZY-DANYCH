/*Zapytanie wyświetla poszczegolne informacje o klientach sortując dane na podstawie nazwiska i imienia*/
CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `zapytanie4` AS
    SELECT 
        `klienci`.`imie` AS `imie`,
        `klienci`.`nazwisko` AS `nazwisko`,
        `klienci`.`pesel` AS `pesel`,
        `klienci`.`adres` AS `adres`,
        `klienci`.`id_klienta` AS `id_klienta`,
        `wypozyczenie`.`data_od` AS `data_od`,
        `wypozyczenie`.`data_do` AS `data_do`
    FROM
        (`klienci`
        LEFT JOIN `wypozyczenie` ON ((`klienci`.`id_klienta` = `wypozyczenie`.`id_klienta`)))
    ORDER BY `klienci`.`nazwisko` , `klienci`.`imie`