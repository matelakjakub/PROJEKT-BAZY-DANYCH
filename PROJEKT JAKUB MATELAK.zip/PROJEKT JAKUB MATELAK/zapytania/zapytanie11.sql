/*Zapytanie poszczegolne informacje o klientach ktorzy urodzili sie w podanym przedziale datowym */

CREATE VIEW `zapytanie11` AS
SELECT id_klienta, imie, nazwisko, miasto_zamieszkania, pesel
FROM klienci
WHERE data_urodzenia BETWEEN '1991-06-14' and '2001-01-23';
