/*Zapytanie wyświetla poszczegolne informacje o samochodach, ktore maja mniejsza pojemnosc silnika od samochodu z id=14*/
CREATE VIEW `zapytanie5` AS
SELECT id_samochodu, marka_samochodu, model_samochodu, nr_rejestracyjny 
FROM samochody
WHERE pojemnosc_silnika < (SELECT pojemnosc_silnika FROM samochody WHERE id_samochodu=14);