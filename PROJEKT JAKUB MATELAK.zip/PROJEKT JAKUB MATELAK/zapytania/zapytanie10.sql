/*Zapytanie wyświetla poszczegolne informacje o przegladzie oraz stanie technicznym samochodu, ktorego waznosc przegladu zaczela sie w poszczegolnym miesiacu */

CREATE VIEW `zapytanie10` AS
SELECT przeglad.id_samochodu,przeglad.data_od, przeglad.data_do, wyposazenie.klimatyzacja, wyposazenie.tempomat
FROM przeglad
INNER JOIN wyposazenie
ON przeglad.id_samochodu=wyposazenie.id_samochodu
WHERE MONTH(data_od) = 08;  
