/*Wyswietla klientów, których imiona kończą się na literę "a"*/

CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `zapytanie1` AS
    SELECT 
        `klienci`.`imie` AS `imie`,
        `klienci`.`nazwisko` AS `nazwisko`,
        `klienci`.`nr_telefonu` AS `nr_telefonu`,
        `wypozyczenie`.`id_wypozyczenia` AS `id_wypozyczenia`
    FROM
        (`klienci`
        JOIN `wypozyczenie` ON ((`klienci`.`id_klienta` = `wypozyczenie`.`id_klienta`)))
    WHERE
        (`klienci`.`imie` LIKE '%a')