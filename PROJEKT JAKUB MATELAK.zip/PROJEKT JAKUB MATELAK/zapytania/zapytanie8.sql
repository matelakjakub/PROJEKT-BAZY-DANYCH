/*Zapytanie wyświetla samochody ktore nie sa czarne oraz maja tyle samo, badz mniej koni mechanicznych od samochodu z podanym id */

CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `zapytanie8` AS
    SELECT 
        `samochody`.`id_samochodu` AS `id_samochodu`,
        `samochody`.`marka_samochodu` AS `marka_samochodu`,
        `samochody`.`model_samochodu` AS `model_samochodu`,
        `samochody`.`rodzaj_silnika` AS `rodzaj_silnika`,
        `samochody`.`moc_silnika` AS `moc_silnika`,
        `samochody`.`klasa_samochodu` AS `klasa_samochodu`,
        `samochody`.`rocznik_samochodu` AS `rocznik_samochodu`,
        `samochody`.`kolor_samochodu` AS `kolor_samochodu`,
        `samochody`.`pojemnosc_silnika` AS `pojemnosc_silnika`,
        `samochody`.`nr_rejestracyjny` AS `nr_rejestracyjny`
    FROM
        `samochody`
    WHERE
        ((`samochody`.`moc_silnika` <= (SELECT 
                `samochody`.`moc_silnika`
            FROM
                `samochody`
            WHERE
                (`samochody`.`id_samochodu` = 10)))
            AND (`samochody`.`kolor_samochodu` <> 'czarny'))