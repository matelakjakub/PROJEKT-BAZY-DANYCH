/* Procedura wyswietla szczegoly wypozyczenia takich samochodów, których miesiąc rozpoczęcia wypożyczenia jest przez nas dowolnie wybierana */

CREATE PROCEDURE `wypozyczenie_szczegoly` (miesiac varchar(40))
BEGIN
SELECT * 
FROM wypozyczenie
WHERE
MONTH(data_od)=miesiac;

END
