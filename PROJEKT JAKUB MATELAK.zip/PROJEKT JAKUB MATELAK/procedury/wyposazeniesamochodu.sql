/* Procedura wyswietla wyposazenie wyposazenie samochodu o id, ktore sami dowolnie wybieramy */

CREATE PROCEDURE `PokazWyposazenieSamochodu` (samochodID INTEGER)
BEGIN
SELECT * FROM wyposazenie
WHERE id_samochodu=samochodID;

END
