/* Trigger ma za zadanie dodawania daty dodania rekordu do tabeli "klienci" */

CREATE TRIGGER dodanie
BEFORE INSERT ON klienci
FOR EACH ROW BEGIN

SET NEW.dodanie = now();

END



