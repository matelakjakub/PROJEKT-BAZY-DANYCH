/* Trigger pokazuje poprzednią cenę za godzinę oraz datę zmiany ceny */
CREATE TRIGGER zmiana
BEFORE UPDATE ON cennik
FOR EACH ROW BEGIN

SET NEW.data_zmiany = now();

IF NEW.cena_godzina=OLD.cena_godzina THEN
SET NEW.poprzednia_cena_godzina = OLD.cena_godzina;
END IF;

END